#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "flight.h"

int main(void) {
    Flight *flights = NULL;
    int choice;
    char s1[DEST_LEN], s2[50];
    int i1, i2, i3;

    while (1) {
        printf(
            "1) Add flight\n"
            "2) Add passenger\n"
            "3) Show flight by index\n"
            "4) Find flight by destination\n"
            "5) Delete flight\n"
            "6) Change passenger seat\n"
            "7) Search passenger flights\n"
            "8) List recurrent passengers\n"
            "9) Exit\n"
            "Select: "
        );
        if (scanf("%d", &choice) != 1) break;

        switch (choice) {
            case 1:
                printf("Flight ID: ");   scanf("%15s", s2);
                printf("Destination: ");  scanf("%31s", s1);
                printf("Seats: ");        scanf("%d", &i1);
                printf("Time: ");         scanf("%d", &i2);
                add_flight(&flights, s2, s1, i1, i2);
                break;

            case 2: {
                printf("Flight index: "); scanf("%d", &i1);
                Flight *f = get_flight_by_index(flights, i1);
                if (!f) { printf("No such flight\n"); break; }
                printf("Seat number: ");  scanf("%d", &i2);
                printf("Name: ");         scanf("%49s", s2);
                printf("Age: ");          scanf("%d", &i3);
                add_passenger(f, i2, s2, i3);
                break;
            }

            case 3:
                printf("Flight index: "); scanf("%d", &i1);
                print_flight(get_flight_by_index(flights, i1));
                break;

            case 4:
                printf("Destination: "); scanf("%31s", s1);
                i1 = find_flight_by_destination(flights, s1);
                if (i1 > 0) printf("Found at %d\n", i1);
                else        printf("Not found\n");
                break;

            case 5:
                printf("Flight index: "); scanf("%d", &i1);
                delete_flight(&flights, get_flight_by_index(flights, i1));
                break;

            case 6:
                printf("Flight index: "); scanf("%d", &i1);
                printf("Passenger name: "); scanf("%49s", s2);
                printf("New seat: "); scanf("%d", &i2);
                change_seat(get_flight_by_index(flights, i1), s2, i2);
                break;

            case 7:
                printf("Name: "); scanf("%49s", s2);
                list_passenger_flights(flights, s2);
                break;

            case 8:
                list_recurrent_passengers(flights);
                break;

            case 9:
                cleanup_flights(&flights);
                return 0;

            default:
                printf("Invalid choice\n");
        }
    }

    cleanup_flights(&flights);
    return 0;
}

