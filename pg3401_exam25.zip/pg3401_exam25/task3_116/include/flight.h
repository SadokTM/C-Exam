#ifndef FLIGHT_H
#define FLIGHT_H

#define ID_LEN    16
#define DEST_LEN  32

typedef struct Passenger {
    int seat_number;
    char name[50];
    int age;
    struct Passenger *next;
} Passenger;

typedef struct Flight {
    char flight_id[ID_LEN];
    char destination[DEST_LEN];
    int seats;
    int time;
    struct Flight *prev;
    struct Flight *next;
    Passenger *passengers;
} Flight;

Flight* add_flight(Flight **head, const char *id, const char *destination, int seats, int time);
Flight* get_flight_by_index(Flight *head, int index);
int     find_flight_by_destination(Flight *head, const char *destination);
int     delete_flight(Flight **head, Flight *flight);
int     add_passenger(Flight *flight, int seat_number, const char *name, int age);
int     change_seat(Flight *flight, const char *name, int new_seat);
void    print_flight(const Flight *flight);
void    list_passenger_flights(Flight *head, const char *name);
void    list_recurrent_passengers(Flight *head);
void    cleanup_flights(Flight **head);

#endif

