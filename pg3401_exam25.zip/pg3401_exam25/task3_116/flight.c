#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "flight.h"

Flight* add_flight(Flight **head, const char *id, const char *destination, int seats, int time)
{
    Flight *node;
    Flight *cur;

    node = (Flight*)malloc(sizeof *node);
    if (!node) return NULL;

    strncpy(node->flight_id, id, ID_LEN-1);
    node->flight_id[ID_LEN-1] = '\0';
    strncpy(node->destination, destination, DEST_LEN-1);
    node->destination[DEST_LEN-1] = '\0';
    node->seats      = seats;
    node->time       = time;
    node->passengers = NULL;
    node->prev = node->next = NULL;

    if (!*head) {
        *head = node;
    } else {
        cur = *head;
        while (cur->next) {
            cur = cur->next;
        }
        cur->next = node;
        node->prev = cur;
    }
    return node;
}

Flight* get_flight_by_index(Flight *head, int index)
{
    Flight *cur;
    int i;

    cur = head;
    i = 1;
    while (cur && i < index) {
        cur = cur->next;
        i++;
    }
    return cur;
}

int find_flight_by_destination(Flight *head, const char *destination)
{
    Flight *cur;
    int i;

    cur = head;
    i = 1;
    while (cur) {
        if (strcmp(cur->destination, destination) == 0) {
            return i;
        }
        cur = cur->next;
        i++;
    }
    return -1;
}

int delete_flight(Flight **head, Flight *flight)
{
    Passenger *p;
    Passenger *tmp;

    if (!flight) return -1;
    if (flight->prev) {
        flight->prev->next = flight->next;
    } else {
        *head = flight->next;
    }
    if (flight->next) {
        flight->next->prev = flight->prev;
    }
    p = flight->passengers;
    while (p) {
        tmp = p->next;
        free(p);
        p = tmp;
    }
    free(flight);
    return 0;
}

int add_passenger(Flight *flight, int seat_number, const char *name, int age)
{
    Passenger **pp;
    Passenger *node;

    pp = &flight->passengers;
    while (*pp && (*pp)->seat_number < seat_number) {
        pp = &(*pp)->next;
    }
    if (*pp && (*pp)->seat_number == seat_number) {
        return -1;
    }
    node = (Passenger*)malloc(sizeof *node);
    if (!node) return -1;
    node->seat_number = seat_number;
    strncpy(node->name, name, sizeof node->name - 1);
    node->name[sizeof node->name - 1] = '\0';
    node->age = age;
    node->next = *pp;
    *pp = node;
    return 0;
}

int change_seat(Flight *flight, const char *name, int new_seat)
{
    Passenger **pp;
    Passenger *found;

    pp = &flight->passengers;
    found = NULL;
    while (*pp) {
        if (strcmp((*pp)->name, name) == 0) {
            found = *pp;
            *pp = (*pp)->next;
            break;
        }
        pp = &(*pp)->next;
    }
    if (!found) return -1;
    return add_passenger(flight, new_seat, found->name, found->age);
}

void print_flight(const Flight *flight)
{
    Passenger *p;

    if (!flight) return;
    printf("Flight %s -> %s, seats=%d, time=%d\n",
        flight->flight_id,
        flight->destination,
        flight->seats,
        flight->time);
    p = flight->passengers;
    while (p) {
        printf("  Seat %d: %s, age %d\n",
            p->seat_number,
            p->name,
            p->age);
        p = p->next;
    }
}

void list_passenger_flights(Flight *head, const char *name)
{
    Flight *f;
    Passenger *p;

    f = head;
    while (f) {
        p = f->passengers;
        while (p) {
            if (strcmp(p->name, name) == 0) {
                printf("%s on flight %s\n", name, f->flight_id);
            }
            p = p->next;
        }
        f = f->next;
    }
}

void list_recurrent_passengers(Flight *head)
{
    Flight *f1;
    Flight *f2;
    Passenger *p1;
    Passenger *p2;
    int count;

    f1 = head;
    while (f1) {
        p1 = f1->passengers;
        while (p1) {
            count = 0;
            f2 = head;
            while (f2) {
                p2 = f2->passengers;
                while (p2) {
                    if (strcmp(p1->name, p2->name) == 0) {
                        count++;
                    }
                    p2 = p2->next;
                }
                f2 = f2->next;
            }
            if (count > 1) {
                printf("%s booked on %d flights\n", p1->name, count);
            }
            p1 = p1->next;
        }
        f1 = f1->next;
    }
}

void cleanup_flights(Flight **head)
{
    while (*head) {
        delete_flight(head, *head);
    }
}

