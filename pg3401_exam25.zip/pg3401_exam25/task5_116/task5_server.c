#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "ewpdef.h"

#define BACKLOG 5
#define HDR_SIZE sizeof(struct EWA_EXAM25_TASK5_PROTOCOL_SIZEHEADER)

static void read_exact(int fd, void *buf, size_t n)
{
    size_t got = 0;
    while (got < n) {
        ssize_t r = read(fd, (char *)buf + got, n - got);
        if (r <= 0) exit(EXIT_FAILURE);
        got += r;
    }
}

static void write_exact(int fd, const void *buf, size_t n)
{
    size_t sent = 0;
    while (sent < n) {
        ssize_t w = write(fd, (const char *)buf + sent, n - sent);
        if (w <= 0) exit(EXIT_FAILURE);
        sent += w;
    }
}

static void fill_sizeheader(struct EWA_EXAM25_TASK5_PROTOCOL_SIZEHEADER *h, int datasize)
{
    char tmp[5];
    memcpy(h->acMagicNumber, EWA_EXAM25_TASK5_PROTOCOL_MAGIC, 3);
    sprintf(tmp, "%04d", datasize);
    memcpy(h->acDataSize, tmp, 4);
    h->acDelimeter[0] = '|';
}

static void send_server_accept(int fd, const char *server_id)
{
    struct EWA_EXAM25_TASK5_PROTOCOL_SERVERACCEPT msg;
    char timestamp[64];
    time_t now;
    struct tm *tm_info;
    now = time(NULL);
    tm_info = localtime(&now);
    strftime(timestamp, sizeof(timestamp), "%d %b %Y, %H:%M:%S", tm_info);
    fill_sizeheader(&msg.stHead, sizeof(msg));
    memcpy(msg.acStatusCode, "220", 3);
    msg.acHardSpace[0] = ' ';
    sprintf(msg.acFormattedString, "%s SMTP %s %s", "127.0.0.1", server_id, timestamp);
    msg.acHardZero[0] = '\0';
    write_exact(fd, &msg, sizeof(msg));
}

static void send_server_reply(int fd, const char *code, const char *text)
{
    struct EWA_EXAM25_TASK5_PROTOCOL_SERVERREPLY msg;
    fill_sizeheader(&msg.stHead, sizeof(msg));
    memcpy(msg.acStatusCode, code, 3);
    msg.acHardSpace[0] = ' ';
    strncpy(msg.acFormattedString, text, sizeof(msg.acFormattedString) - 1);
    msg.acFormattedString[sizeof(msg.acFormattedString) - 1] = '\0';
    msg.acHardZero[0] = '\0';
    write_exact(fd, &msg, sizeof(msg));
}

static int valid_filename(const char *name)
{
    const char *p;
    if (!name || !*name) return 0;
    for (p = name; *p; ++p) {
        if (!(((*p) >= 'a' && (*p) <= 'z') ||
              ((*p) >= 'A' && (*p) <= 'Z') ||
              ((*p) >= '0' && (*p) <= '9') ||
               *p == '.' || *p == '_' || *p == '-'))
            return 0;
    }
    return 1;
}

int main(int argc, char *argv[])
{
    int port = 0, sockfd, clientfd, i;
    char *server_id = NULL;
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t cli_len = sizeof(cli_addr);

    for (i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "-port") == 0 && i + 1 < argc) {
            port = atoi(argv[++i]);
        } else if (strcmp(argv[i], "-id") == 0 && i + 1 < argc) {
            server_id = argv[++i];
        } else {
            fprintf(stderr, "Usage: %s -port PORT -id SERVERID\n", argv[0]);
            exit(EXIT_FAILURE);
        }
    }
    if (port <= 0 || !server_id) {
        fprintf(stderr, "Usage: %s -port PORT -id SERVERID\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) exit(EXIT_FAILURE);
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serv_addr.sin_port = htons(port);
    if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) exit(EXIT_FAILURE);
    if (listen(sockfd, BACKLOG) < 0) exit(EXIT_FAILURE);
    clientfd = accept(sockfd, (struct sockaddr *)&cli_addr, &cli_len);
    if (clientfd < 0) exit(EXIT_FAILURE);
    send_server_accept(clientfd, server_id);

    for (;;) {
        struct EWA_EXAM25_TASK5_PROTOCOL_SIZEHEADER hdr;
        int datasz, payload_len;
        char *payload, *pfx;

        read_exact(clientfd, &hdr, HDR_SIZE);
        if (strncmp(hdr.acMagicNumber, EWA_EXAM25_TASK5_PROTOCOL_MAGIC, 3) != 0 ||
            hdr.acDelimeter[0] != '|') break;
        datasz = atoi(hdr.acDataSize);
        payload_len = datasz - HDR_SIZE;
        payload = malloc(payload_len + 1);
        if (!payload) exit(EXIT_FAILURE);
        read_exact(clientfd, payload, payload_len);
        payload[payload_len] = '\0';
        pfx = payload;

        if (strncmp(pfx, "HELO ", 5) == 0) {
            char *dot, work[51], text[64];
            strncpy(work, payload + 5, 50);
            work[50] = '\0';
            dot = strchr(work, '.');
            if (dot) {
                *dot = '\0';
                sprintf(text, "%s Hello %s", dot + 1, work);
                send_server_reply(clientfd, EWA_EXAM25_TASK5_PROTOCOL_SERVERREPLY_OK, text);
            }
            free(payload);
        } else if (strncmp(pfx, "MAIL FROM:", 10) == 0) {
            free(payload);
            send_server_reply(clientfd, EWA_EXAM25_TASK5_PROTOCOL_SERVERREPLY_OK, "Sender address ok");
        } else if (strncmp(pfx, "RCPT TO:", 8) == 0) {
            free(payload);
            send_server_reply(clientfd, EWA_EXAM25_TASK5_PROTOCOL_SERVERREPLY_OK, "Recipient ok");
        } else if (strncmp(pfx, "DATA ", 5) == 0) {
            char filename[51];
            int valid;
            FILE *f;
            strncpy(filename, payload + 5, 50);
            filename[50] = '\0';
            free(payload);
            valid = valid_filename(filename);
            if (!valid) {
                send_server_reply(clientfd, "501", "Invalid filename");
            } else {
                send_server_reply(clientfd, EWA_EXAM25_TASK5_PROTOCOL_SERVERREPLY_READY, "Ready for data");
                f = fopen(filename, "wb");
                if (!f) {
                    send_server_reply(clientfd, "550", "Cannot save file");
                } else {
                    for (;;) {
                        struct EWA_EXAM25_TASK5_PROTOCOL_SIZEHEADER fhdr;
                        int fsz, fpayload;
                        char *buf, *term;
                        read_exact(clientfd, &fhdr, HDR_SIZE);
                        if (strncmp(fhdr.acMagicNumber, EWA_EXAM25_TASK5_PROTOCOL_MAGIC, 3) != 0 ||
                            fhdr.acDelimeter[0] != '|') break;
                        fsz = atoi(fhdr.acDataSize);
                        fpayload = fsz - HDR_SIZE;
                        buf = malloc(fpayload + 1);
                        if (!buf) exit(EXIT_FAILURE);
                        read_exact(clientfd, buf, fpayload);
                        buf[fpayload] = '\0';
                        term = strstr(buf, "\r\n.\r\n");
                        if (term) {
                            fwrite(buf, 1, term - buf, f);
                            free(buf);
                            break;
                        }
                        fwrite(buf, 1, fpayload, f);
                        free(buf);
                    }
                    fclose(f);
                    send_server_reply(clientfd, EWA_EXAM25_TASK5_PROTOCOL_SERVERREPLY_OK, "Message saved");
                }
            }
        } else if (strncmp(pfx, "QUIT", 4) == 0) {
            free(payload);
            send_server_reply(clientfd, EWA_EXAM25_TASK5_PROTOCOL_SERVERREPLY_CLOSED, "Closing connection");
            break;
        } else {
            free(payload);
            break;
        }
    }

    close(clientfd);
    close(sockfd);
    return 0;
}

