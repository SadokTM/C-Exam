#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

#define BUF_SIZE 4096
#define BLOCK_SZ 64

typedef struct {
    unsigned char    buf[BUF_SIZE];
    size_t           len;
    sem_t            empty;
    sem_t            full;
    pthread_mutex_t  mtx;
} channel_t;

typedef struct {
    const char   *fname;
    channel_t    *chan;
} argA_t;

static const unsigned long tea_key[4] = {
    0xA56BABCDUL,
    0x0000FACEUL,
    0xDEADBEEFUL,
    0x12345678UL
};

static void encipher(unsigned long v[2], const unsigned long k[4])
{
    unsigned long y = v[0], z = v[1], sum = 0;
    const unsigned long delta = 0x9E3779B9UL;
    unsigned long a = k[0], b = k[1], c = k[2], d = k[3];
    for (unsigned long n = 0; n < 32; n++) {
        sum += delta;
        y   += ((z << 4) + a) ^ (z + sum) ^ ((z >> 5) + b);
        z   += ((y << 4) + c) ^ (y + sum) ^ ((y >> 5) + d);
    }
    v[0] = y;
    v[1] = z;
}

static unsigned long djb2_data(const unsigned char *data, size_t len)
{
    unsigned long hash = 5381;
    for (size_t i = 0; i < len; ++i) {
        hash = ((hash << 5) + hash) + data[i];
    }
    return hash;
}

void *thread_A(void *arg)
{
    argA_t    *a = (argA_t *)arg;
    channel_t *c = a->chan;
    FILE      *f = fopen(a->fname, "rb");
    size_t     r;

    if (!f) {
        perror("fopen");
        return NULL;
    }

    do {
        sem_wait(&c->empty);
        pthread_mutex_lock(&c->mtx);
        r      = fread(c->buf, 1, BUF_SIZE, f);
        c->len = r;
        pthread_mutex_unlock(&c->mtx);
        sem_post(&c->full);
    } while (r == BUF_SIZE);

    fclose(f);
    return NULL;
}

void *thread_B(void *arg)
{
    channel_t    *c = (channel_t *)arg;
    unsigned char *data = NULL;
    size_t         total = 0, cap = 0, n;
    long           pad;
    FILE          *fhash, *fenc;

    do {
        sem_wait(&c->full);
        pthread_mutex_lock(&c->mtx);
        n = c->len;
        if (total + n > cap) {
            cap  = (total + n) * 2;
            data = realloc(data, cap);
        }
        memcpy(data + total, c->buf, n);
        total += n;
        pthread_mutex_unlock(&c->mtx);
        sem_post(&c->empty);
    } while (n == BUF_SIZE);

    unsigned long h = djb2_data(data, total);
    fhash = fopen("task4_pg2265.hash", "w");
    fprintf(fhash, "%lu\n", h);
    fclose(fhash);

    pad   = BLOCK_SZ - (total % BLOCK_SZ);
    data  = realloc(data, total + pad);
    memset(data + total, pad, pad);
    total += pad;

    for (size_t i = 0; i < total; i += 8) {
        encipher((unsigned long *)(data + i), tea_key);
    }

    fenc = fopen("task4_pg2265.enc", "wb");
    fwrite(data, 1, total, fenc);
    fclose(fenc);

    free(data);
    return NULL;
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input_file>\n", argv[0]);
        return EXIT_FAILURE;
    }

    channel_t    chan;
    pthread_t    tidA, tidB;
    argA_t       a;

    sem_init(&chan.empty, 0, 1);
    sem_init(&chan.full,  0, 0);
    pthread_mutex_init(&chan.mtx, NULL);

    a.fname = argv[1];
    a.chan  = &chan;

    pthread_create(&tidA, NULL, thread_A, &a);
    pthread_create(&tidB, NULL, thread_B, &chan);

    pthread_join(tidA, NULL);
    pthread_join(tidB, NULL);

    sem_destroy(&chan.empty);
    sem_destroy(&chan.full);
    pthread_mutex_destroy(&chan.mtx);

    return EXIT_SUCCESS;
}

