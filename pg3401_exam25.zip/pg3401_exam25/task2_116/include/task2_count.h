#ifndef TASK2_COUNT_H
#define TASK2_COUNT_H

#include <stdio.h>

int Task2_CountEachCharacter(FILE *f, char aCountarray[26]);

#endif
