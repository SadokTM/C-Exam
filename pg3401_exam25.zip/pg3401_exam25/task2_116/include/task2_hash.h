#ifndef TASK2_HASH_H
#define TASK2_HASH_H

#include <stdio.h>

int Task2_SimpleDjb2Hash(FILE *f, unsigned int *pHash);

#endif
