#ifndef TASK2_SUM_H
#define TASK2_SUM_H

#include <stdio.h>

int Task2_SizeAndSumOfCharacters(FILE *f, int *pSizeOfFile, int *pSumOfChars);

#endif
