#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "task2_hash.h"
#include "task2_count.h"
#include "task2_sum.h"

struct TASK2_FILE_METADATA {
    char          szFileName[32];
    int           iFileSize;
    unsigned char byHash[4];
    int           iSumOfChars;
    char          aAlphaCount[26];
};

static void write_metadata(const struct TASK2_FILE_METADATA *md)
{
    FILE *out;

    out = fopen("pgexam25_output.bin", "wb");
    if (!out)
        exit(1);
    fwrite(md, sizeof *md, 1, out);
    fclose(out);
}

int main(void)
{
    const char *infile = "pgexam25_test.txt";
    FILE *f;
    int sz, sum;
    unsigned char *buf;
    struct TASK2_FILE_METADATA md;
    unsigned int h;

    sz = 0;
    sum = 0;

    f = fopen(infile, "rb");
    if (!f)
        return 1;

    if (Task2_SizeAndSumOfCharacters(f, &sz, &sum) != 0) {
        fclose(f);
        return 1;
    }

    rewind(f);

    buf = malloc(sz > 0 ? sz : 1);
    if (!buf) {
        fclose(f);
        return 1;
    }

    fread(buf, 1, sz, f);
    free(buf);

    rewind(f);

    memset(&md, 0, sizeof md);
    strncpy(md.szFileName, infile, sizeof md.szFileName - 1);
    md.iFileSize   = sz;
    md.iSumOfChars = sum;

    if (Task2_CountEachCharacter(f, md.aAlphaCount) != 0) {
        fclose(f);
        return 1;
    }

    if (Task2_SimpleDjb2Hash(f, &h) != 0) {
        fclose(f);
        return 1;
    }
    fclose(f);

    md.byHash[0] = (h      ) & 0xFF;
    md.byHash[1] = ((h >>  8) & 0xFF);
    md.byHash[2] = ((h >> 16) & 0xFF);
    md.byHash[3] = ((h >> 24) & 0xFF);

    write_metadata(&md);

    return 0;
}

